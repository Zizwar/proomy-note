import React from 'react';
import { FAB } from 'react-native-paper';
import { styles } from '../styles';

export default function FloatingActionButton({ onPress }) {
  return (
    <FAB
      style={styles.fab}
      icon="plus"
      onPress={onPress}
    />
  );
}