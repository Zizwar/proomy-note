import React from 'react';
import { View, Linking } from 'react-native';
import { Modal, Portal, Title, Button, RadioButton, Paragraph } from 'react-native-paper';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { styles } from '../styles';

export default function SettingsModal({ visible, onDismiss }) {
  const { t, i18n } = useTranslation();
  const [language, setLanguage] = React.useState(i18n.language);

  const changeLanguage = async (lang) => {
    await AsyncStorage.setItem('language', lang);
    i18n.changeLanguage(lang);
    setLanguage(lang);
  };

  return (
    <Portal>
      <Modal visible={visible} onDismiss={onDismiss} contentContainerStyle={styles.modalContent}>
        <Title>{t('settings')}</Title>
        <View>
          <Title>{t('language')}</Title>
          <RadioButton.Group onValueChange={changeLanguage} value={language}>
            <RadioButton.Item label="English" value="en" />
            <RadioButton.Item label="العربية" value="ar" />
          </RadioButton.Group>
        </View>
        <View style={styles.settingsSection}>
          <Title>{t('privacyPolicy')}</Title>
          <Paragraph>{t('privacyPolicyText')}</Paragraph>
        </View>
        <View style={styles.settingsSection}>
          <Title>{t('termsAndConditions')}</Title>
          <Paragraph>{t('termsAndConditionsText')}</Paragraph>
        </View>
        <View style={styles.settingsSection}>
          <Title>{t('openSource')}</Title>
          <Paragraph>{t('openSourceDescription')}</Paragraph>
          <Button onPress={() => Linking.openURL('https://github.com/zizwar/proomy-note')}>
            {t('viewOnGitHub')}
          </Button>
        </View>
        <Button onPress={onDismiss}>{t('close')}</Button>
      </Modal>
    </Portal>
  );
}