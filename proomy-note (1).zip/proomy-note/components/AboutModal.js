import React from 'react';
import { Modal, Text, Button, VStack, Link } from 'native-base';
import { useTranslation } from 'react-i18next';

export default function AboutModal({ isOpen, onClose }) {
  const { t } = useTranslation();

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <Modal.Content maxWidth="400px">
        <Modal.CloseButton />
        <Modal.Header>{t('about')}</Modal.Header>
        <Modal.Body>
          <VStack space={4}>
            <Text>{t('aboutDescription')}</Text>
            <Text>{t('openSourceInfo')}</Text>
            <Link href="https://github.com/zizwar/prompty-note" isExternal>
              {t('viewOnGitHub')}
            </Link>
          </VStack>
        </Modal.Body>
        <Modal.Footer>
          <Button onPress={onClose}>{t('close')}</Button>
        </Modal.Footer>
      </Modal.Content>
    </Modal>
  );
}