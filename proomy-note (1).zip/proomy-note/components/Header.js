import React from 'react';
import { View } from 'react-native';
import { Appbar, Searchbar, Chip } from 'react-native-paper';
import { useTranslation } from 'react-i18next';
import { styles } from '../styles';

const categories = ['all', 'personal', 'work', 'ideas'];

export default function Header({ onSearch, onCategoryChange, onOpenSettings }) {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = React.useState('');

  const onChangeSearch = query => {
    setSearchQuery(query);
    onSearch(query);
  };

  return (
    <View>
      <Appbar.Header>
        <Appbar.Content title={t('appName')} />
        <Appbar.Action icon="cog" onPress={onOpenSettings} />
      </Appbar.Header>
      <Searchbar
        placeholder={t('search')}
        onChangeText={onChangeSearch}
        value={searchQuery}
        style={styles.searchBar}
      />
      <View style={styles.categories}>
        {categories.map((category) => (
          <Chip
            key={category}
            onPress={() => onCategoryChange(category)}
            style={styles.categoryChip}
          >
            {t(category)}
          </Chip>
        ))}
      </View>
    </View>
  );
}