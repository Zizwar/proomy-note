import React, { useState } from 'react';
import { Modal, FormControl, Input, Button, VStack, Select, useToast } from 'native-base';
import { useTranslation } from 'react-i18next';

export default function AddNoteModal({ isOpen, onClose, onAdd }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('image');
  const { t } = useTranslation();
  const toast = useToast();

  const handleAdd = () => {
    if (title.trim() === '') {
      toast.show({
        title: t('titleRequired'),
        status: "warning",
        placement: "top"
      });
      return;
    }
    onAdd({ title, content, category });
    setTitle('');
    setContent('');
    setCategory('image');
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <Modal.Content maxWidth="400px">
        <Modal.CloseButton />
        <Modal.Header>{t('addNewNote')}</Modal.Header>
        <Modal.Body>
          <VStack space={3}>
            <FormControl isRequired>
              <FormControl.Label>{t('title')}</FormControl.Label>
              <Input value={title} onChangeText={setTitle} />
            </FormControl>
            <FormControl>
              <FormControl.Label>{t('content')}</FormControl.Label>
              <Input value={content} onChangeText={setContent} multiline numberOfLines={4} />
            </FormControl>
            <FormControl>
              <FormControl.Label>{t('category')}</FormControl.Label>
              <Select selectedValue={category} onValueChange={setCategory}>
                <Select.Item label={t('image')} value="image" />
                <Select.Item label={t('code')} value="code" />
                <Select.Item label={t('video')} value="video" />
              </Select>
            </FormControl>
          </VStack>
        </Modal.Body>
        <Modal.Footer>
          <Button.Group space={2}>
            <Button variant="ghost" onPress={onClose}>
              {t('cancel')}
            </Button>
            <Button onPress={handleAdd}>{t('add')}</Button>
          </Button.Group>
        </Modal.Footer>
      </Modal.Content>
    </Modal>
  );
}