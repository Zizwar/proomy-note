import React from 'react';
import { HStack, IconButton, Image } from 'native-base';

const backgrounds = [
  'https://images.pexels.com/photos/799443/pexels-photo-799443.jpeg',
  'https://images.pexels.com/photos/9040445/pexels-photo-9040445.jpeg',
  'https://images.pexels.com/photos/1745766/pexels-photo-1745766.jpeg',
];

export default function BackgroundSelector({ onSelectBackground }) {
  return (
    <HStack position="absolute" bottom={16} right={4} bg="rgba(255,255,255,0.7)" rounded="full" p={2}>
      {backgrounds.map((bg, index) => (
        <IconButton
          key={index}
          icon={
            <Image
              source={{ uri: bg }}
              alt={`Background ${index + 1}`}
              size="xs"
              rounded="full"
            />
          }
          onPress={() => onSelectBackground(bg)}
          mr={index < backgrounds.length - 1 ? 2 : 0}
          rounded="full"
          overflow="hidden"
        />
      ))}
    </HStack>
  );
}