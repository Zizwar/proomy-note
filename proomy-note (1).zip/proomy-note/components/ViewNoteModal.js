import React from 'react';
import { ScrollView } from 'react-native';
import { Modal, Portal, Title, Paragraph, Button } from 'react-native-paper';
import { useTranslation } from 'react-i18next';
import * as Clipboard from 'expo-clipboard';
import { styles } from '../styles';

export default function ViewNoteModal({ visible, onDismiss, note }) {
  const { t } = useTranslation();

  const copyToClipboard = async () => {
    await Clipboard.setStringAsync(`${note.title}\n\n${note.content}`);
  };

  if (!note) return null;

  return (
    <Portal>
      <Modal visible={visible} onDismiss={onDismiss} contentContainerStyle={styles.modalContent}>
        <ScrollView>
          <Title>{note.title}</Title>
          <Paragraph style={styles.noteCategory}>{t(note.category)}</Paragraph>
          <Paragraph>{note.content}</Paragraph>
        </ScrollView>
        <Button onPress={copyToClipboard}>{t('copy')}</Button>
        <Button onPress={onDismiss}>{t('close')}</Button>
      </Modal>
    </Portal>
  );
}