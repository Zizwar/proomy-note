import React from 'react';
import { Fab, Icon } from 'native-base';
import { Ionicons } from '@expo/vector-icons';

export default function AddButton({ onPress }) {
  return (
    <Fab
      position="absolute"
      size="sm"
      icon={<Icon color="white" as={Ionicons} name="add" size="sm" />}
      onPress={onPress}
    />
  );
}