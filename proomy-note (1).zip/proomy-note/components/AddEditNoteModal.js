import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import { Modal, Portal, TextInput, Button, RadioButton } from 'react-native-paper';
import { useTranslation } from 'react-i18next';
import { styles } from '../styles';

export default function AddEditNoteModal({ visible, onDismiss, onSave, note, mode }) {
  const { t } = useTranslation();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('personal');

  useEffect(() => {
    if (note && mode === 'edit') {
      setTitle(note.title);
      setContent(note.content);
      setCategory(note.category);
    }
  }, [note, mode]);

  const handleSave = () => {
    if (title.trim() === '') {
      // Show error
      return;
    }
    onSave({ id: note?.id, title, content, category });
    onDismiss();
  };

  return (
    <Portal>
      <Modal visible={visible} onDismiss={onDismiss} contentContainerStyle={styles.modalContent}>
        <TextInput
          label={t('title')}
          value={title}
          onChangeText={setTitle}
          style={styles.input}
        />
        <TextInput
          label={t('content')}
          value={content}
          onChangeText={setContent}
          multiline
          numberOfLines={4}
          style={styles.input}
        />
        <RadioButton.Group onValueChange={setCategory} value={category}>
          <RadioButton.Item label={t('personal')} value="personal" />
          <RadioButton.Item label={t('work')} value="work" />
          <RadioButton.Item label={t('ideas')} value="ideas" />
        </RadioButton.Group>
        <View style={styles.modalActions}>
          <Button onPress={onDismiss}>{t('cancel')}</Button>
          <Button onPress={handleSave}>{t('save')}</Button>
        </View>
      </Modal>
    </Portal>
  );
}