// components/NoteItem.js
import React from 'react';
import { List, IconButton } from 'react-native-paper';
import { useTranslation } from 'react-i18next';

export default function NoteItem({ note, onEdit, onView, onDelete }) {
  const { t } = useTranslation();

  return (
    <List.Item
      title={note.title}
      description={note.content}
      left={props => <List.Icon {...props} icon="note" />}
      right={props => (
        <>
          <IconButton {...props} icon="eye" onPress={onView} />
          <IconButton {...props} icon="pencil" onPress={onEdit} />
          <IconButton {...props} icon="delete" onPress={onDelete} />
        </>
      )}
    />
  );
}