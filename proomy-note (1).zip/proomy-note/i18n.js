import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      appName: 'Proomy Note',
      search: 'Search notes...',
      all: 'All',
      personal: 'Personal',
      work: 'Work',
      ideas: 'Ideas',
      settings: 'Settings',
      language: 'Language',
      title: 'Title',
      content: 'Content',
      category: 'Category',
      cancel: 'Cancel',
      save: 'Save',
      copy: 'Copy to Clipboard',
      close: 'Close',
      delete: 'Delete',
      edit: 'Edit',
      privacyPolicy: 'Privacy Policy',
      privacyPolicyText: 'This app does not collect or store any personal data. All notes are stored locally on your device.',
      termsAndConditions: 'Terms and Conditions',
      termsAndConditionsText: 'By using this app, you agree to use it at your own risk. The developers are not responsible for any loss of data.',
      openSource: 'Open Source',
      openSourceDescription: 'This app is open-source and available on GitHub.',
      viewOnGitHub: 'View on GitHub',
    },
  },
  ar: {
    translation: {
      appName: 'مذكرة برومي',
      search: 'البحث في الملاحظات...',
      all: 'الكل',
      personal: 'شخصي',
      work: 'عمل',
      ideas: 'أفكار',
      settings: 'الإعدادات',
      language: 'اللغة',
      title: 'العنوان',
      content: 'المحتوى',
      category: 'الفئة',
      cancel: 'إلغاء',
      save: 'حفظ',
      copy: 'نسخ إلى الحافظة',
      close: 'إغلاق',
      delete: 'حذف',
      edit: 'تعديل',
      privacyPolicy: 'سياسة الخصوصية',
      privacyPolicyText: 'هذا التطبيق لا يجمع أو يخزن أي بيانات شخصية. جميع الملاحظات يتم تخزينها محليًا على جهازك.',
      termsAndConditions: 'الشروط والأحكام',
      termsAndConditionsText: 'باستخدامك لهذا التطبيق، فإنك توافق على استخدامه على مسؤوليتك الخاصة. المطورون غير مسؤولين عن أي فقدان للبيانات.',
      openSource: 'مفتوح المصدر',
      openSourceDescription: 'هذا التطبيق مفتوح المصدر ومتاح على GitHub.',
      viewOnGitHub: 'عرض على GitHub',
    },
  },
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;